import aws_cdk as cdk
import aws_cdk.aws_ec2 as ec2
from constructs import Construct

class NetworkStack(cdk.Stack):
    def __init__(self, scope: Construct, id: str, **kwargs):
        super().__init__(scope, id, **kwargs)

        # Create a VPC
        self.vpc = ec2.Vpc(self, "VPC",
                           max_azs=2,
                           subnet_configuration=[
                               ec2.SubnetConfiguration(
                                   cidr_mask=24,
                                   name="PublicSubnet",
                                   subnet_type=ec2.SubnetType.PUBLIC,
                               ),
                               ec2.SubnetConfiguration(
                                   cidr_mask=24,
                                   name="PrivateSubnet",
                                   subnet_type=ec2.SubnetType.PRIVATE_ISOLATED,
                               )
                           ])

        # Create a NAT Gateway
        self.nat_gateway = ec2.NatGateway(self, 'NatGateway',
                                           subnet=self.vpc.public_subnets[0])  # Choose one of the public subnets

        # Add a route table entry for the private subnets to use the NAT Gateway
        for subnet in self.vpc.private_subnets:
            route_table = ec2.RouteTable(self, f'{subnet.node.id}RouteTable', vpc=self.vpc)
            route_table.add_route('DefaultRoute', destination_cidr_block='0.0.0.0/0', nat_gateway=self.nat_gateway)
            subnet.route_table_association(route_table)
